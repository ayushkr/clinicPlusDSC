 


aylinker({
    // urlOfTemplate: "/clinicPlus/module/" +mn.module.current+ "/all/list/template1.html?ran=" + Math.random(),
    urlOfTemplate: "/clinicPlus/search/search.html?ran=" + Math.random(),
    selector: "main_1_inner",
    data: {obj: ''}
}
);

console.log('help .js loaded');

