 
console.log('1.js of patient');

manifestGUISelectLarge('dateOfRegistration',apiDataGlobal.dateOfRegistration);

