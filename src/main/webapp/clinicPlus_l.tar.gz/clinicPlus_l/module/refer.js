setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);

// Simulate a mouse click:
window.location.href = "http://www.w3schools.com";

// Simulate an HTTP redirect:
window.location.replace("http://www.w3schools.com");
 result.json = JSON.stringify(result, null, 2);
    //@ManyToOne
   // @JoinColumn(name = "pharmacyBill")
   // @OnDelete(action = OnDeleteAction.CASCADE)